import { Component, OnInit } from "@angular/core";
import { map } from "rxjs/operators";

@Component({
  selector: "app-scanner",
  templateUrl: "./scanner.component.html",
  styleUrls: ["./scanner.component.scss"]
})
export class ScannerComponent implements OnInit {



  qrResultString: string;
  result1:string;
  isClicked=false;
  test:string;
  constructor() {}

  ngOnInit(): void {}

  clearResult(): void {
    this.qrResultString = null;
  }
  onCodeResult(resultString: string) {
   this.qrResultString = resultString;
    if(resultString.includes("https://"))
    {
      this.result1 = resultString;
    }
    else
    {
      this.test="https://";
      this.result1 =this.test.concat( resultString);
    }
    //this.router.navigate(['/scanResult/:resultString']);
    
  }


}
