export class Filter {
    id: number;
    name: string;
    url: string;
    desc: string;
}
export class Coupon {
    id: number;
    name: string;
    url: string;
    desc: string;
    hasChild: boolean;
}
export class Cart {
    id: number;
    name: string;
    image: string;
    price: number;
}
export class Category {
    id: number;
    cName: string;
}
export class Brand {
    id: number;
    bName: string;
}
export class ViewList {
    id: number;
    vName: string;
}
export class MenuList {
    id: number;
    mName: string;
    url: string;
}
export class Country {
    CountryId: number;
    Country: string;
    CountryCode: number;
    CountryIcon: string;
}
