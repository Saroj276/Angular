import { EventEmitterService } from './services/EventEmitter/event-emitter.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { CouponCardComponent } from './pages/coupon/coupon-card/coupon-card.component';
import { FilterComponent } from './pages/coupon/filter/filter.component';
import { OfferDetailsComponent } from './pages/offer-details/offer-details.component';
import { NgOtpInputModule } from 'ng-otp-input';
import { ShowCouponComponent } from './pages/coupon/show-coupon/show-coupon.component';
import { HeaderComponent } from './pages/header/header.component';
import { SurveyNewComponent } from './pages/survey-new/survey-new.component';
import { CouponServiceService } from './services/coupon/coupon-service.service';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { LoginComponent } from './pages/login/login.component';
import { FooterComponent } from './pages/footer/footer.component';
import { OfferDetails2Component } from './pages/offer-details2/offer-details2.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { HomeComponent } from './pages/home/home.component';
import { CartComponent } from './pages/cart/cart.component';
import { ClaimHeaderComponent } from './pages/claim-header/claim-header.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SearchBarComponent } from './pages/search-bar/search-bar.component';
import { EarnHeaderComponent } from './pages/earn-header/earn-header.component';
import { DashboarddeskComponent } from './pages/dashboarddesk/dashboarddesk.component';
import { LoginNewComponent } from './pages/login-new/login-new.component';
import { RegistrationNewComponent } from './pages/registration-new/registration-new.component';
import { LoginHeaderComponent } from './pages/login-header/login-header.component';
// import { ModalModule } from 'ngx-bootstrap/modal';
import { ProductCardComponent } from './pages/product-card/product-card.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { SearchPageComponent } from './pages/search-page/search-page.component';
import { SearchMenuComponent } from './pages/search-menu/search-menu.component';
import { CategorypageComponent } from './pages/categorypage/categorypage.component';
import { ScrollComponent } from './pages/scroll/scroll.component';
import { ProdscrollComponent } from './pages/prodscroll/prodscroll.component';
import { HttpClientModule } from '@angular/common/http';
import { LocationComponent } from './pages/location/location.component';
import { WalletComponent } from './pages/wallet/wallet.component';
import { SigninService } from './services/signin/signin.service';
import { CartService } from './services/cart/cart.service';
import { ScannerComponent } from './pages/scanner/scanner.component';
import { Scanner1Service } from "./services/scanner1.service";
import { ZXingScannerModule } from "@zxing/ngx-scanner";
import { ShareComponent } from './pages/share/share.component';

@NgModule({
  declarations: [
    AppComponent,
    FilterComponent,
    CouponCardComponent,
    HeaderComponent,
    ShowCouponComponent,
    OfferDetailsComponent,
    SurveyNewComponent,
    OfferDetails2Component,
    DashboardComponent,
    LoginComponent,
    FooterComponent,
    RegistrationComponent,
    HomeComponent,
    CartComponent,
    ClaimHeaderComponent,
    EarnHeaderComponent,
    SearchBarComponent,
    DashboarddeskComponent,
    LoginNewComponent,
    RegistrationNewComponent,
    LoginHeaderComponent,
    ProductCardComponent,
    SearchPageComponent,
    SearchMenuComponent,
    CategorypageComponent,
    ScrollComponent,
    ProdscrollComponent,
    LocationComponent,
    WalletComponent,
    ScannerComponent,
    ShareComponent,
  ],
  imports: [
    HttpClientModule,
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    NgOtpInputModule,
    BrowserAnimationsModule,
    Ng2SearchPipeModule,ZXingScannerModule
    // ModalModule,
    // ModalModule.forRoot(),
  ],
  providers: [CouponServiceService, EventEmitterService, SigninService, CartService,Scanner1Service],
  bootstrap: [AppComponent]
})
export class AppModule { }
