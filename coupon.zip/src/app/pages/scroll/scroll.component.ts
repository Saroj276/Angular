import { Component, OnInit, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { CouponServiceService } from 'src/app/services/coupon/coupon-service.service';

@Component({
  selector: 'app-scroll',
  templateUrl: './scroll.component.html',
  styleUrls: ['./scroll.component.scss']
})
export class ScrollComponent implements OnInit {
  showView = true;
  public text = 'View All';
  public categoryArrays = [];
  public scrollCard = [];
  constructor(
    public router: Router,
    private couponService: CouponServiceService,
  ) { }

  // [
  //   {
  //     id: 1,
  //     name: 'Women\'s Fashion',
  //     imgURL: 'assets/img/WF1.jpg',
  //   },
  //   {
  //     id: 2,
  //     name: 'Men\'s Fashion',
  //     imgURL: 'assets/img/menF2.jpg',
  //   },
  //   {
  //     id: 3,
  //     name: 'Jewelry',
  //     imgURL: 'assets/img/FP.jpg',
  //   },
  //   {
  //     id: 4,
  //     name: ' Beauty',
  //     imgURL: 'assets/img/bp.jpg',
  //   },
  //   {
  //     id: 5,
  //     name: '  Mobiles and Digital',
  //     imgURL: 'assets/img/g.jpg',
  //   },
  //   {
  //     id: 6,
  //     name: 'Eat Out',
  //     imgURL: 'assets/img/et6.jpg',
  //   },
  //   {
  //     id: 7,
  //     name: 'Fun',
  //     imgURL: 'assets/img/lg4.jpg',
  //   },
  //   {
  //     id: 8,
  //     name: 'Grocery',
  //     imgURL: 'assets/img/dv1.jpg',
  //   }
  // ];

  ngOnInit() {
    this.getAllCategory();
    this.getAllSubCategory();
    console.log("card list is ",this.scrollCard);
  }
  openViewAll() {
    if (this.text === 'View All') {
      this.text = 'View Less';
    } else {
      this.text = 'View All';
    }
    console.log('texttt', this.text);
    console.log('showView', this.showView);
    console.log("card list is ",this.scrollCard);
    this.showView = !this.showView;
  }
  openHome() {
    this.router.navigate(['/home']);
  }

  // public getAllSubCategoryByCatId(data) {
  //   this.couponService.getAllSubCategoryByCatId(data).subscribe(result => {
  //       console.log('=========== getAllSubCategoryByCatId Details: ' + data + '===========');
  //       console.log('getAllSubCategoryByCatId issss .......', result.categoryResponses);
  //   }, error => {
  //     console.log(error);
  //   });
  // }
  getAllCategory() {
    this.couponService.getAllCategory().subscribe(data => {
      // console.log(data);
      // this.couponsList = data.responseList;
      this.scrollCard = data.categoryResponses;
      // console.log(this.scrollCard);
      this.splitCategoryArray();
      // console.log(this.scrollCard);
    }, error => {
      console.log(error);
      alert('Some Error Occured');
    });
  }
  splitCategoryArray() {
    const category = this.scrollCard.slice(0);
    while (category.length) {
      this.categoryArrays.push(category.splice(0, 4))
    }
    // console.log(this.scrollCard);
  }
  getAllSubCategory() {
    this.couponService.getAllSubCategory().subscribe(data => {
      // console.log(data);
      // this.couponsList = data.responseList;
    }, error => {
      console.log(error);
    });
  }

}
