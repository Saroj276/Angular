import { Component, OnInit, Input, ViewChild, HostListener } from '@angular/core';
import { CouponServiceService } from './../../services/coupon/coupon-service.service';
import { Router } from '@angular/router';
import { OfferService } from 'src/app/services/offer/offer.service';
import { CartService } from 'src/app/services/cart/cart.service';

import { Scanner1Service } from 'src/app/services/scanner1.service';
@Component({
  selector: 'app-offer-details2',
  templateUrl: './offer-details2.component.html',
  styleUrls: ['./offer-details2.component.scss']
})


export class OfferDetails2Component implements OnInit {

  otp: string;
  applogcon=true;
  actv1: boolean = true;
  actv2: boolean = true;
  qrResult: boolean = false;

  showOtpComponent = true;
  claim = false;
  public headerFix = false;
  isDisable = true;
  isDisableClaim = true;
  public cupDiv = true;
  public claimCode = true;
  public showCode: any = false;
  public imgURL = 'assets/img/galaxyZ.png';
  @Input() ClaimCode: boolean;
  @ViewChild('ngOtpInput', { static: true }) ngOtpInputRef: any;
  config = {
    allowNumbersOnly: true,
    length: 4,
    isPasswordInput: false,
    disableAutoFocus: false,
    placeholder: '',
    inputStyles: {
      width: '13vw',
      height: '13vw',
      'border-radius': '1px solid #c5c5c5',
      border: '0',
      margin: '3% 0% 3% 0%',
      outline: '1px solid #bbbbbb',
      'text-align': 'center',
      'font-size': '17px',
      'background-color': 'rgba(236, 236, 236, 0.59)'
    }
  };
  public offerDetails =
    ['Get 6 months of add-free youTube and YouTube premium Trail. ',
      'Offer is not applicable for existing YouTube  premium Trail user.',
      'Check your subscribtion deatils for YouTube premuium at https://www.youtube.com/paid_memberships',
      'This offer can not be clubbed with any othe ongoing offer discount/cash back promotion.',
      'Reedem the offer within 15 days of claim.'];
  public note =
    ['To use the offer on youtube customer need to mandatory update credit/detit cards details ',
      'Restricted debit/credit cards that have reccuring payment options allowed for the offer'];
  coupon: any;
  public couponCode: any;

  constructor(
    private couponService: CouponServiceService,
    private offerService: OfferService,
    private cartService: CartService,
    public router: Router,
  ) { }
  ngOnInit() {
    const data = JSON.parse(localStorage.getItem('subProdDetails'));
    if (data) {
      this.coupon = data;
      this.imgURL = 'https://wifi10x.com/' + data.imgSrc;
    }
    console.log(this.ngOtpInputRef);
    // this.sendOTP();
  }
  @HostListener('window:scroll', ['$event']) // for window scroll events
  onScrollEvent(event) {
    // console.log(event);
    const data = window.scrollY;
    // this.change.emit(data);
    // this.service.emitScrollEvent(data);
    // console.log(data);
    if (data > 49) {
      this.headerFix = true;
    } else {
      this.headerFix = false;
    }
  }
  eventFired(event) {
    console.log(event);
    if (event) { 
      this.actv2=false;
      const data = {
        subproductId: 1,
        userId: 1,
        otp: '1234'
      };
      if (this.coupon) {
        data.subproductId = this.coupon.id;
      }
      this.offerService.ValidateOTPforCoupon(data).subscribe(
        result => {
          if (result.status === 200) {
            this.isDisable = false;
            this.showCode = true;
            this.qrResult = true;
            this.couponCode = result.couponResponses[0].couponCode;
            localStorage.setItem("code", this.couponCode);
            localStorage.setItem("subprodId", result.couponResponses[0].subproductId);
          } else {
            this.isDisable = true;
            this.isDisableClaim = true;
            this.showCode = false;
            alert(result.statusDesc);
            this.otp = ' ';
            this.ngOtpInputRef.setValue('');
          }
        }, error => {
          console.log(error);
        }
      );
    }
  }
  onOtpChange(otp) {
    this.otp = otp;
    // console.log('otp', this.otp);
    if (this.otp.length === 4) {
      // if (this.otp === '1234') {
      //   this.isDisable = false;
      //   this.showCode = true;
      // } else {
      //   this.isDisable = true;
      //   this.isDisableClaim = true;
      //   this.showCode = false;
      //   alert('Invalid OTP');
      //   this.otp = ' ';
      //   console.log(this.ngOtpInputRef);
      //   this.ngOtpInputRef.setValue('');
      // }
      const data = {
        subproductId: 1,
        userId: 1,
        otp: this.otp
      };
      if (this.coupon) {
        data.subproductId = this.coupon.id;
      }
      this.offerService.ValidateOTPforCoupon(data).subscribe(
        result => {
          // console.log(result);
          if (result.status === 200) {
            this.isDisable = false;
            this.showCode = true;
            this.couponCode = result.couponResponses[0].couponCode;
            localStorage.setItem("code", this.couponCode);
            localStorage.setItem("subprodId", result.couponResponses[0].subproductId);
          } else {
            this.isDisable = true;
            this.isDisableClaim = true;
            this.showCode = false;
            alert(result.statusDesc);
            this.otp = ' ';
            this.ngOtpInputRef.setValue('');
          }
        }, error => {
          console.log(error);
        }
      );

    }
  }
  sendOTP() {
    const data = {
      subproductId: 1,
      userId: 1
    };
    if (this.coupon) {
      data.subproductId = this.coupon.id;
    }
    this.offerService.sendOTPforCoupon(data).subscribe(
      result => {
        console.log(result);
        alert('OTP sent Successfully');
      }, error => {
        console.log(error);
        alert('Some Error Occured');
      }
    );
  }
  // setVal(val) {
  //   this.ngOtpInput.setValue(val);
  // }
  onConfigChange() {
    this.showOtpComponent = false;
    this.otp = null;
    setTimeout(() => {
      this.showOtpComponent = true;
    }, 0);
  }

  claimRewords() {
    this.claimCode = true;
    this.showCode = true;
  }
  copyCode(val: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = val;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.isDisableClaim = false;
  }
  claimCoupon() {
    // if (this.coupon.id === 1) {
      const data = {
        subproductId: 1,
        userId: 1,
        quantity: 1
      };
    if (this.coupon) {
      data.subproductId = this.coupon.id;
    }
    this.cartService.addToCart(data).subscribe(
      res => {
        console.log(res);
        this.router.navigate(['/cart']);
      }, err => {
        console.log(err);
        alert('Some error Occured');
      }
    );
    // localStorage.setItem('code', 'WIF222287542');
    // }
    // else {
    //   localStorage.clear();
    //   document.location.href = 'https://www.noon.com/';
    // }
  }

  addtoWalletBtn() {
    
    this.addtoWallet();
  }
  public addtoWallet() {
    const data = {
     /*  id: 1,
      userId: '1',
      productId: 1,
      quantity: 145 */
   
      mobileNo:917205512384,
      subproductId: 15,
      quantity: 145
    };
    this.couponService.addToWallet(data).subscribe(result => {
      console.log('AddToWallet Details: ', result);
      // this.AddToWallet = result.reponseList;
      // console.log('AddToWallet issss .......', result.reponseList);
    }, error => {
      console.log(error);
    });
  }



}
