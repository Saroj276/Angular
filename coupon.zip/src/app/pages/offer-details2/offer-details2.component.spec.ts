import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferDetails2Component } from './offer-details2.component';

describe('OfferDetails2Component', () => {
  let component: OfferDetails2Component;
  let fixture: ComponentFixture<OfferDetails2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferDetails2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferDetails2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
