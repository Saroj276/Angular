import { Component, OnInit, HostListener } from '@angular/core';
import * as $ from 'jquery';
import { CouponServiceService } from 'src/app/services/coupon/coupon-service.service';

@Component({
  selector: 'app-categorypage',
  templateUrl: './categorypage.component.html',
  styleUrls: ['./categorypage.component.scss']
})
export class CategorypageComponent implements OnInit {

  public headerFix = false;
  constructor(
    private couponService: CouponServiceService,
  ) { }

  ngOnInit() {

  }

  @HostListener('window:scroll', ['$event']) // for window scroll events
  onScrollEvent(event) {
    // console.log(event);
    const data = window.scrollY;
    // this.change.emit(data);
    // this.service.emitScrollEvent(data);
    // console.log(data);
    if (data > 49) {
      this.headerFix = true;
    } else {
      this.headerFix = false;
    }
    // document.getElementById('carouselExampleSlidesOnly').classList.add('pointer-event');
    // $('#carouselExampleSlidesOnly').carousel();
    // document.getElementById('carouselExampleSlidesOnly').carousel({ interval: 3000, cycle: true });
    // console.log(document.getElementById('carouselExampleSlidesOnly').classList);
  }

  

}
