import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-earn-header',
  templateUrl: './earn-header.component.html',
  styleUrls: ['./earn-header.component.scss']
})
export class EarnHeaderComponent implements OnInit {

  constructor() { }
  @Input() showLogo = false;
  ngOnInit() {
  }

}
