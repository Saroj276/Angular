import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EarnHeaderComponent } from './earn-header.component';

describe('EarnHeaderComponent', () => {
  let component: EarnHeaderComponent;
  let fixture: ComponentFixture<EarnHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EarnHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EarnHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
