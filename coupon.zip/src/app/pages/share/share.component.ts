import { Component, OnInit } from '@angular/core';
import { Country } from 'src/app/data/data';
@Component({
  selector: 'app-share',
  templateUrl: './share.component.html',
  styleUrls: ['./share.component.scss']
})
export class ShareComponent implements OnInit {

  public country: Country[];
  public selectedCountry: Country;
  starIcon = false;
  otp: string;
  mobileNo: number;
  mobile: string;
  showOtpComponent = true;
  showCountryModal = false;
  claim = false;
  isDisableLogin = true;
  isDisableClaim = true;
  disableSendOTP = true;
  disableInput = false;

  constructor() { }

  ngOnInit() {
    
    this.country = [
      {
        CountryId: 392,
        Country: 'INDIA',
        CountryCode: 91,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/in.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      }
    ];
    this.selectedCountry = this.country[1];
  
  }
  validateNumber() {
    if (this.mobileNo != null && this.mobileNo.toString().length > 9) {
      this.disableSendOTP = false;
    } else {
      this.disableSendOTP = true;
    }
    // console.log(this.mobileNo.toString().length, this.disableSendOTP);
  }
  shareCoupon()
  {

  }
}
