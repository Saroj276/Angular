import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public menuCrossImg = 'assets/img/menuicon.svg';
  public menuToggle = false;
  constructor(
    public router: Router,
    private route: ActivatedRoute,
  ) {

  }

  ngOnInit() {
    if (this.router.url === '/searchMenu') {
      this.menuToggle = true;
    } else {
      this.menuToggle = false;
    }

  }
  categoryPg() {
    this.router.navigate(['/category']);
  }

  async toggleMenu() {
    this.menuToggle = !this.menuToggle;
    if (this.menuToggle === true) {
      this.router.navigate(['/searchMenu']);
    } else {
      this.router.navigate(['../']);

    }
  }
}
