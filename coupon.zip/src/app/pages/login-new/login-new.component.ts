import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Country } from 'src/app/data/data';
import { SigninService } from 'src/app/services/signin/signin.service';

@Component({
  selector: 'app-login-new',
  templateUrl: './login-new.component.html',
  styleUrls: ['./login-new.component.scss']
})
export class LoginNewComponent implements OnInit {
  starIcon = false;
  otp: string;
  mobileNo: number;
  mobile: string;
  showOtpComponent = true;
  showCountryModal = false;
  claim = false;
  isDisableLogin = true;
  isDisableClaim = true;
  disableSendOTP = true;
  disableInput = false;
  public showCode = false;
  public country: Country[];
  public selectedCountry: Country;
  @Input() ClaimCode: boolean;
  @ViewChild('ngOtpInput', { static: true }) ngOtpInput: any;
  config = {
    allowNumbersOnly: true,
    length: 4,
    isPasswordInput: false,
    disableAutoFocus: true,
    placeholder: '',
    containerStyles: {
      width: '100%',
      // padding: '0.5rem !important';
    },
    inputStyles: {
      width: '12vw',
      height: '12vw',
      // 'margin-right': '11%',
      // 'div: nth - child(n + 6)' ? 'background-color:grr' : 'red',
      'border-radius': '0px !important',
      border: '0',
      outline: '1px solid #bbbbbb',
      'text-align': 'center',
      'font-size': '17px',
      'background-color': 'rgba(236, 236, 236, 0.59)'
    }
  };

  constructor(
    public router: Router,
    private route: ActivatedRoute,
    private loginService: SigninService
  ) { }

  ngOnInit() {
    this.country = [
      {
        CountryId: 392,
        Country: 'INDIA',
        CountryCode: 91,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/in.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      },
      {
        CountryId: 375,
        Country: 'UNITED ARAB EMIRATES',
        CountryCode: 971,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/ae.svg'
      },
      {
        CountryId: 24,
        Country: 'AUSTRALIA',
        CountryCode: 61,
        CountryIcon: 'https://caccount.policybazaar.com/content/countryIcon/au.svg'
      }
    ];
    this.selectedCountry = this.country[1];
  }

  onOtpChange(otp) {
    this.otp = otp;
    // this.mobile = '+' + this.selectedCountry.CountryCode + this.mobileNo;
    // console.log('otp', this.otp);
    // if (this.otp === '1234') {
    //   this.isDisable = false;
    //   this.showCode = true;
    // } else {
    //   this.isDisable = true;
    //   this.isDisableClaim = true;
    //   this.showCode = false;
    //   if (this.otp.length === 4) {
    //     alert('Invalid OTP');
    //     // tslint:disable: no-unused-expression
    //     this.otp === ' ';
    //     console.log(this.ngOtpInput);
    //     this.ngOtpInput.setValue('');
    //   }
    // }
    if (this.otp.length === 4) {
      const data = {
        mobileNo: this.mobile,
        otp: this.otp
      }
      this.loginService.validateOtp(data).subscribe(
        res => {
          if (res.status == 200) {
            this.isDisableLogin = false;
            localStorage.setItem("mobileNo",this.mobile);
          }
          else
          {
            alert("Wrong OTP");
          }

          // console.log(res);
         
        }, err => {
          console.log(err);
          alert('Invalid OTP');
          this.disableInput = false;
        }
      );
    }
  }

  clickCountry(data) {
    // console.log(data);
    this.selectedCountry = data;
  }
  numberOnly(event): boolean {
    console.log(event);
    // console.log(this.mobileNo.length, event);
    // console.log(this.mobileNo.length > 9);
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 31 && (charCode < 48 || charCode > 57)) || this.mobileNo.toString().length > 15) {
      return false;
    }
    return true;
  }
  validateNumber() {
    if (this.mobileNo != null && this.mobileNo.toString().length > 9) {
      this.disableSendOTP = false;
    } else {
      this.disableSendOTP = true;
    }
    // console.log(this.mobileNo.toString().length, this.disableSendOTP);
  }

  sendOTP() {
    console.log('+' + this.selectedCountry.CountryCode + this.mobileNo);
    this.mobile = '+' + this.selectedCountry.CountryCode + this.mobileNo;
    if (confirm('Are you sure to send OTP to ' + this.mobile)) {
      // console.log('Confirmed');
      this.loginService.sendOTP({ mobileNo: this.mobile }).subscribe(
        res => {
          // console.log(res);
          this.disableSendOTP = true;
          this.disableInput = true;
        }, err => {
          console.log(err);
        }
      );
    }
  }

  login() {
    this.router.navigate(['/home']);
  }
  toggleIcon() {
    this.starIcon = !this.starIcon;

  }
}

