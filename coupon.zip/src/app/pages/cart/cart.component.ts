import { Component, OnInit, HostListener } from '@angular/core';
import { Cart } from 'src/app/data/data';
import { CouponServiceService } from 'src/app/services/coupon/coupon-service.service';
import { CartService } from 'src/app/services/cart/cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {
  public show: boolean = false;
  public buttonName: any = 'Apply';
  public showDiscount: boolean;
  public headerFix = false;
  public totalAmtCalc: any;
  discount = 'Extra Discount';
  subtotal = 'Subtotal';
  total = 'Total';
  shipping = 'Shipping';
  // discountList: string[] = ['300.00'];
  // subtotalList: string[] = ['4299.00'];
  shippingList: string[] = ['FREE'];
  // totalAmt: string[] = ['4299.00 '];
  public filters: Cart[];
  public cartResp = [];
  public couponResp: any;
  constructor(
    private couponService: CouponServiceService,
    private cartService: CartService,
    public router: Router
  ) {
    this.filters = [
      {
        id: 1,
        name: 'Perfume 1',
        image: 'assets/img/prod5.jpg',
        price: 2000,
      },
      {
        id: 2,
        name: 'Perfume 2',
        image: 'assets/img/prod5.jpg',
        price: 2000,
      },
      {
        id: 3,
        name: 'Perfume 3',
        image: 'assets/img/prod5.jpg',
        price: 2000,
      },
      {
        id: 4,
        name: 'Perfume 4',
        image: 'assets/img/prod5.jpg',
        price: 2000,
      },
      // {
      //   id: 5,
      //   name: 'Perfume 5',
      //   image: 'assets/img/prod5.jpg',
      //   price : 2000,
      // },
      // {
      //   id: 6,
      //   name: 'Perfume 6',
      //   image: 'assets/img/prod5.jpg',
      //   price : 2000,
      // },
    ];
  }

  ngOnInit() {
    this.getAllCart()
    this.showDiscount = false;
    // localStorage.setItem('code', 'WIF22230909');
  }
  @HostListener('window:scroll', ['$event']) // for window scroll events
  onScrollEvent(event) {
    // console.log(event);
    const data = window.scrollY;
    // this.change.emit(data);
    // this.service.emitScrollEvent(data);
    // console.log(data);
    // COU457
    if (data > 49) {
      this.headerFix = true;
    } else {
      this.headerFix = false;
    }
  }

  showDiscountAmt(subProductPrice, subProductOfferPrice) {
    this.show = !this.show;
    console.log('subProductPrice, subProductOfferPrice', subProductPrice, subProductOfferPrice);
    let tAmount: number = parseFloat(subProductPrice) - parseFloat(subProductOfferPrice);
    this.totalAmtCalc = tAmount.toFixed(2);

    // this.show = !this.show;
    // let tAmount: any = parseFloat(this.totalAmt[0]);
    // let sAmount: any = parseFloat(this.subtotalList[0]);
    // let dAmount: any = parseFloat(this.discountList[0]);
    // tAmount = sAmount - dAmount;
    // this.totalAmtCalc = tAmount;
    // this.showDiscount= false;
  }

  applyBtnClick(value: string) {
    var coupon = localStorage.getItem('code');
    var subProdId = localStorage.getItem('subprodId')
    console.log(value);
    const data = {
      subproductId: subProdId,
      couponCode: coupon,
      userId: 1
    };
    this.cartService.validateCouponCode(data).subscribe(
      res => {
        // console.log(res);
        if (value === coupon) {
          console.log("Coupon Code matched");
          this.showDiscount = true;
          this.couponResp = res;
          console.log("couponResp", this.couponResp);
          this.showDiscountAmt(this.couponResp['subProductPrice'], this.couponResp['subProductOfferPrice']);
        } else {
          alert("Invalid Coupon");
          this.showDiscount = false;
        }
      }, err => {
        console.log(err);
        // alert("Invalid Coupon");
        this.showDiscount = false;
      }
    );
    // if (value === coupon) {
    //   console.log("Coupon Code matched");
    //   this.showDiscount = true;
    //   // this.showDiscountAmt();
    // }
    // else {
    //   // console.log("Quit");
    //   alert("Invalid Coupon");
    //   this.showDiscount = false;
    // }
    // return this.showDiscount;
    // if (value !== null) {
    //   this.applyBtnClick = false;
    // } else {
    //   this.applyBtnClick = true;
    // }
    // console.log("WIF22230909", value);
  }

  getAllCart() {
    this.couponService.getAllCart().subscribe(data => {
      console.log(data);
      this.cartResp = data.cartResponses;
      // this.totalAmtCalc = this.cartResp[0].subProductPrice;
      // console.log(this.totalAmtCalc);
    }, error => {
      console.log(error);
    });
  }



}
