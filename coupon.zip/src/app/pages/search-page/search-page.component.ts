import { Component, OnInit } from '@angular/core';
import { MenuList } from 'src/app/data/data';
@Component({
  selector: 'app-search-page',
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.scss']
})
export class SearchPageComponent implements OnInit {
  public menuList: MenuList[];
  constructor() { }

  ngOnInit() {
    this.menuList = [
      {
        id: 1,
        mName: 'Categories',
        url: '/search'
      },
      {
        id: 2,
        mName: 'Brands',
        url: '/search'
      },
      {
        id: 3,
        mName: 'How its Works',
        url: '/'

      }, {
        id: 4,
        mName: 'Register',
        url: '/login/register'
      }
    ];

  }

}
