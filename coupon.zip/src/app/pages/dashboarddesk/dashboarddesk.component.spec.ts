import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboarddeskComponent } from './dashboarddesk.component';

describe('DashboarddeskComponent', () => {
  let component: DashboarddeskComponent;
  let fixture: ComponentFixture<DashboarddeskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboarddeskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboarddeskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
