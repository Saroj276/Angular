import { EventEmitterService } from './../../services/EventEmitter/event-emitter.service';
import { Component, OnInit, HostListener, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { CouponServiceService } from 'src/app/services/coupon/coupon-service.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  public show = false;
  public headerFix = false;
  public scrollY: string;
  public difference = 280;
  public value = 250;
  public change: EventEmitter<number> = new EventEmitter<number>();
  public coupons: any;

  constructor(
    public router: Router,
    private couponService: CouponServiceService,
    private service: EventEmitterService
  ) { }

  ngOnInit() {
    this.getAllProduct();
  }
  @HostListener('window:scroll', ['$event']) // for window scroll events
  onScrollEvent(event) {
    // console.log(event);
    const data = window.scrollY;
    this.change.emit(data);
    this.service.emitScrollEvent(data);
    // console.log(data);
    if (data > 49) {
      this.headerFix = true;
    } else {
      this.headerFix = false;
    }
  }
  getAllProduct() {
    this.couponService.getAllProduct().subscribe(data => {
      // console.log(data);
      this.coupons = data.productresponses;
      console.log('AllProduct List:', this.coupons);
    }, error => {
      console.log(error);
    });
  }

}
