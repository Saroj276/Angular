import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProdscrollComponent } from './prodscroll.component';

describe('ProdscrollComponent', () => {
  let component: ProdscrollComponent;
  let fixture: ComponentFixture<ProdscrollComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProdscrollComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProdscrollComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
