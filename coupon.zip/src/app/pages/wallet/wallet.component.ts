import { Component, OnInit, HostListener } from '@angular/core';
import { CouponServiceService } from 'src/app/services/coupon/coupon-service.service';

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.scss']
})
export class WalletComponent implements OnInit {

  public headerFix = false;
  // public difference = 280;
  public value = 250;
  public value1 = 250;
  public coupons=[];
  public couponList=[];
  // public coupons = [
  //   {
  //     id: 4,
  //     productName: 'Tops',
  //     productDesc: 'Flat 25% off',
  //     productPrice: 3000,
  //     productOfferPrice: 2500,
  //     productWeight: 200,
  //     productWeightMeasure: 'gram',
  //     productManufacturer: 'AMBH',
  //     productSpecification1: 'Cotton',
  //     productSpecification2: 'Printed',
  //     productSpecification3: 'Printed',
  //     productSpecification4: 'Printed',
  //     productSpecification5: 'Printed',
  //     productOverview1: 'Red',
  //     productOverview2: 'Light',
  //     productOverview3: 'Light',
  //     productOverview4: 'Cotton',
  //     productOverview5: 'Light',
  //     subProducts: [
  //       {
  //         subProductName: 'Floral Tops',
  //         subProductDesc: 'A premium denim brand thats earned acclaim for its fine fits, fabrics and finishes.',
  //         subProductPrice: 2500,
  //         subProductOfferPrice: 2250,
  //         subProductWeight: 100,
  //         subProductWeightMeasure: 'gram',
  //         subProductManufacturer: 'AMBH',
  //         subProductSpecification1: 'Cotton',
  //         subProductOverview1: 'Floral',
  //         size: 'M',
  //         imgSrc: 'Video/Coupon/Product/abmh.png',
  //         extraPrice: 'Rs.250',
  //         button: '\'Earn ! AED 300\'',
  //         productId: 4
  //       },
  //       {
  //         subProductName: 'Formal Tops',
  //         subProductDesc: 'A premium denim brand thats earned acclaim for its fine fits, fabrics and finishes.',
  //         subProductPrice: 2500,
  //         subProductOfferPrice: 2000,
  //         subProductWeight: 100,
  //         subProductWeightMeasure: 'gram',
  //         subProductManufacturer: 'AMBH',
  //         subProductSpecification1: 'Cotton',
  //         subProductOverview1: 'Formal',
  //         size: 'XXL',
  //         imgSrc: 'Video/Coupon/Product/abmh.png',
  //         extraPrice: 'Rs.500',
  //         button: '\'Earn ! AED 300\'',
  //         productId: 4
  //       }
  //     ],
  //     imgSrc: 'Video/Coupon/Product/abmh.png',
  //     extraPrice: 'Rs.500',
  //     buttonName: 'Earn Extra! Up to AED 300',
  //     catId: 1,
  //     subcatId: 1,
  //     brandId: 4,
  //     discountId: 0
  //   },
  //   {
  //     id: 2,
  //     productName: 'Canvas Shoes',
  //     productDesc: '125 AED discount',
  //     productPrice: 2200,
  //     productOfferPrice: 2000,
  //     productWeight: 200,
  //     productWeightMeasure: 'gram',
  //     productManufacturer: 'clymb',
  //     productSpecification1: 'Canvas',
  //     productSpecification2: 'Synthetic',
  //     productSpecification3: 'comfort',
  //     productSpecification4: 'washable',
  //     productSpecification5: 'good',
  //     productOverview1: 'White Colour',
  //     productOverview2: 'Good',
  //     productOverview3: 'Good',
  //     productOverview4: 'Awesome',
  //     productOverview5: 'comfortable',
  //     subProducts: [],
  //     imgSrc: 'Video/Coupon/Product/clymb.png',
  //     extraPrice: 'Rs.200',
  //     buttonName: 'Earn Extra! Up to AED 300',
  //     catId: 1,
  //     subcatId: 1,
  //     brandId: 2,
  //     discountId: 0
  //   },
  // ];
  constructor(
    private couponService: CouponServiceService,
  ) { }

  ngOnInit() {
    this.getAllWallet();
    this.getWishList();
  }

  @HostListener('window:scroll', ['$event']) // for window scroll events
  onScrollEvent(event) {
    // console.log(event);
    const data = window.scrollY;
    // this.change.emit(data);
    // this.service.emitScrollEvent(data);
    // console.log(data);
    if (data > 49) {
      this.headerFix = true;
    } else {
      this.headerFix = false;
    }
  }

  getAllWallet() {
    this.couponService.getAllWallet().subscribe(data => {
      // console.log(data);
      this.coupons = data.walletResponses;
      console.log('walletResponses List:', this.coupons);
    }, error => {
      console.log(error);
    });
  }

  getWishList() {
    this.couponService.getWishList().subscribe(result => {
      // console.log("Result issss ",result);
      this.couponList = result.wishResponses;
      console.log('wishResponses List:', this.couponList);
    }, error => {
      console.log(error);
    });
  }
}
