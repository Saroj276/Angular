import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  animations: [
    trigger('showHello', [
      // transition(':enter',
      //   [style({ transform: 'translateY(100%)', opacity: 0 }),
      //   animate('2000ms', style({ transform: 'translateY(0)', 'opacity': 1 }))]),
      transition(':leave', [
        style({ transform: 'translateY(0)' }),
        animate('500ms', style({ transform: 'translateY(-100%)' }))
      ])
    ])
  ]
})
export class HomeComponent implements OnInit {

  public portalBg = true;
  public homeBg;
  public visible: boolean;
  public videoVisible = false;
  @ViewChild('myVideo', { static: true }) myVideo: ElementRef; // => Angular 8
  public video1: string;

  constructor(
    public router: Router,
    private route: ActivatedRoute,
  ) { }

  ngOnInit() {
  }
  homeClick() {
    if (!this.videoVisible) {
      this.visible = false;
      this.myVideo.nativeElement.load();
      // $('#main-header').slideUp(2000);
      setTimeout(() => {
        // this.router.navigateByUrl('/pages/video1');
        // this.router.navigateByUrl('/video1');
        // if (this.pageService.ad.adTypeId === 1) {
        this.videoVisible = true;
        this.video1 = 'assets/img/SamsungAd2.mp4';
        // this.video1 = 'https://wifi10x.com/Video/Samsung2.mp4';
        this.myVideo.nativeElement.load();
        // const video = document.getElementById('myVideo');
        this.myVideo.nativeElement.play();
        // this.myVideo.nativeElement.muted = true;
        // this.myVideo.nativeElement.controls = true;
        console.log(this.myVideo);
        // } else {
        //   this.router.navigate(['/login']);
        // }
        // video.nativeElement.play();
      }, 510);
    }
  }
  videoEnd() {
    if (this.videoVisible) {
      // console.log("workingggg.....")
      // this.router.navigate(['/cart']);
      // document.location.href ='https://wifi10x.com/';
      document.location.href = 'http://test.wifi10x.com/Coupon';
    }

  }
  
}
