import { EventEmitterService } from './../../services/EventEmitter/event-emitter.service';
import { Component, OnInit, HostListener, Input } from '@angular/core';
import { Router } from '@angular/router';
import { CouponServiceService } from 'src/app/services/coupon/coupon-service.service';
@Component({
  selector: 'app-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.scss']
})
export class ProductCardComponent implements OnInit {
  @Input() firstValue: number;
  @Input() difference: number;
  // @Input() firstValue1: number;
  // @Input() difference1: number;
  public scrollValue: any;
  public wishStringVar: any;
  public boolValue: any;
  @Input() coupons: any;
  @Input() couponList: any;
  public prodCard = [];
  var1 = String;
  var2 = String;
  public subProdListbyId: any;
  public scrollEvent: any;
  public buttonFix = false;
  shareCon=false;
  showDiv = true;
  varBtn: string;
  activeCard = false;
  fixBtnTog = false;
  hideDiv = false;
  openSharePop = true;
  plusMInus = false;
  height = '30vh';
  toggleBtn = false;
  mobileNo=localStorage.getItem("mobileNo");
  // public coupons = [
  //   {
  //     id: 1,
  //     name: 'Samsung',
  //     desc: '125 AED discount',
  //     expDate: '11-06-2020',
  //     imgURL: './assets/img/galaxyZ.png',
  //     btnText: 'Earn Extra! Upto',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 2,
  //     name: 'Coach',
  //     desc: '125 AED discount',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/coach.png',
  //     btnText: 'Earn Extra! Upto ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 3,
  //     name: 'ABMH',
  //     desc: 'Flat 25% off',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/abmh.png',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 4,
  //     name: 'Jimmy Choo Shoes',
  //     desc: 'Flat 25% off',
  //     expDate: '31-09-2020',
  //     imgURL: 'assets/img/jimmy.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 5,
  //     name: 'Jobb',
  //     desc: 'Flat 25% off',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/jobb.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 6,
  //     name: 'giovani',
  //     desc: '300 AED discount',
  //     expDate: '31-05-2020',
  //     imgURL: 'assets/img/giovani.jpg',
  //     btnText: 'Earn Extra! Upto ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 7,
  //     name: 'Moncet',
  //     desc: '100 AED discount',
  //     expDate: '1-07-2020',
  //     imgURL: 'assets/img/moncet.jpg',
  //     btnText: 'Earn Extra! Upto',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 8,
  //     name: 'Fiola',
  //     desc: 'Flat 25% off',
  //     expDate: '31-09-2020',
  //     imgURL: 'assets/img/fiola.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 9,
  //     name: 'Tymx',
  //     desc: '125 AED discount',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/tymx.jpg',
  //     btnText: 'Earn Extra! Upto ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 10,
  //     name: 'Dior',
  //     desc: 'Flat 25% off',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/dior.png',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 11,
  //     name: 'Paris Perfumes',
  //     desc: 'Flat 20% off',
  //     expDate: '21-07-2020',
  //     imgURL: 'assets/img/paris.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 12,
  //     name: 'Black Cosmetics',
  //     desc: '300 AED discount',
  //     expDate: '31-05-2020',
  //     imgURL: 'assets/img/black.jpg',
  //     btnText: 'Earn Extra! Upto',
  //     amt: 'AED 300'
  //   },

  //   {
  //     id: 13,
  //     name: 'galaxyZ',
  //     desc: '125 AED discount',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/galaxyZ.png',
  //     btnText: 'Earn Extra! Upto ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 14,
  //     name: 'Beyond',
  //     desc: '300 AED discount',
  //     expDate: '31-06-2020',
  //     imgURL: 'assets/img/beyond.jpg',
  //     btnText: 'Earn Extra! Upto ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 15,
  //     name: 'Apple',
  //     desc: 'Flat 25% off',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/apple.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },

  //   {
  //     id: 16,
  //     name: 'Doors',
  //     desc: '125 AED discount',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/doors.jpg',
  //     btnText: 'Earn Extra! Upto ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 17,
  //     name: 'Fujiya',
  //     desc: '125 AED discount',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/fujiya.jpg',
  //     btnText: 'Earn Extra! ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 18,
  //     name: 'Jumeirah',
  //     desc: '300 AED discount',
  //     expDate: '25-09-2020',
  //     imgURL: 'assets/img/jumeirah.jpg',
  //     btnText: 'Earn Extra! ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 19,
  //     name: 'Lego Land',
  //     desc: 'flat 20% off ',
  //     expDate: '19-08-2020',
  //     imgURL: 'assets/img/legoLand.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 20,
  //     name: 'Ain Dubai',
  //     desc: '100 AED discount',
  //     expDate: '31-12-2020',
  //     imgURL: 'assets/img/ainDubai.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 21,
  //     name: 'Louvre',
  //     desc: '125 AED discount',
  //     expDate: '11-06-2020',
  //     imgURL: 'assets/img/louvre.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 22,
  //     name: 'Oreo',
  //     desc: 'Flat 25% off',
  //     expDate: '31-05-2020',
  //     imgURL: 'assets/img/oreo.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  //   {
  //     id: 23,
  //     name: 'Nespresso',
  //     desc: 'AED 250 off',
  //     expDate: '31-08-2020',
  //     imgURL: 'assets/img/nespresso.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   }, {
  //     id: 24,
  //     name: 'Nivea',
  //     desc: 'Flat 25% off',
  //     expDate: '31-05-2020',
  //     imgURL: 'assets/img/nivea.jpg',
  //     btnText: 'Earn Extra!  ',
  //     amt: 'AED 300'
  //   },
  // ];
  // public prodCard = [
  //   {
  //     id: 2,
  //     name: 'Gucci Bag',
  //     desc: ' A premium denim brand thats earned acclaim for its fine fits, fabrics and finishes.',
  //     // expDate: '19-08-2020',
  //     size: 'Medium',
  //     retailPrice: 'Est. Retail 20,106.94 AED',
  //     offPrice: '8.106.94 AED   56% Off',
  //     extPrice: '5,106.94 AED EXTRA 40% Off',
  //     imgURL: 'assets/img/gucci.jpg',
  //     btnText: 'Earn ! AED 300'
  //   },
  //   {
  //     id: 3,
  //     name: 'adidas',
  //     desc: ' A premium denim brand thats earned acclaim for its fine fits, fabrics and finishes.',
  //     // expDate: '20-08-2020',
  //     size: 'Medium',
  //     retailPrice: 'Est. Retail 20,106.94 AED',
  //     offPrice: '8.106.94 AED   56% Off',
  //     extPrice: '5,106.94 AED EXTRA 40% Off',
  //     imgURL: 'assets/img/adidas.jpg',
  //     btnText: 'Earn ! AED 300'
  //   },
  //   //  {
  //   //   id: 3,
  //   //   name: 'Gucci Bag',
  //   //   desc: ' A premium denim brand thats earned acclaim for its fine fits, fabrics and finishes. ',
  //   //   expDate: '19-08-2020',
  //   //   imgURL: 'assets/img/gucci.jpg',
  //   //   btnText: 'Earn ! AED 300'
  //   // }, {
  //   //   id: 4,
  //   //   name: 'Gucci Deo',
  //   //   desc: 'A premium denim brand thats earned acclaim for its fine fits, fabrics and finishes.',
  //   //   expDate: '31-12-2020',
  //   //   imgURL: 'assets/img/couponimg1.jpg',
  //   //   btnText: 'Earn ! AED 300'
  //   // }, {
  //   //   id: 5,
  //   //   name: 'Oreo',
  //   //   desc: 'A premium denim brand thats earned acclaim for its fine fits, fabrics and finishes.',
  //   //   expDate: '31-05-2020',
  //   //   imgURL: 'assets/img/oreo.jpg',
  //   //   btnText: 'Earn ! AED 300'
  //   // },
  //   // {
  //   //   id: 6,
  //   //   name: 'Fujiya',
  //   //   desc: 'A premium denim brand thats earned acclaim for its fine fits, fabrics and finishes.',
  //   //   expDate: '31-12-2020',
  //   //   imgURL: 'assets/img/fujiya.jpg',
  //   //   btnText: 'Earn ! AED 300'
  //   // },
  //   {
  //     id: 4,
  //     name: 'Ain Dubai',
  //     desc: ' A premium denim brand thats earned acclaim for its fine fits, fabrics and finishes.',
  //     // expDate: '31-12-2020',
  //     size: 'Medium',
  //     retailPrice: 'Est. Retail 20,106.94 AED',
  //     offPrice: '8.106.94 AED   56% Off',
  //     extPrice: '5,106.94 AED EXTRA 40% Off',
  //     imgURL: 'assets/img/ainDubai.jpg',
  //     btnText: 'Earn ! AED 300'
  //   },
  // ];

  constructor(
    public router: Router,
    private service: EventEmitterService,
    private couponService: CouponServiceService,

  ) {
    this.scrollEvent = this.service.onChange.subscribe({
      next: (data: any) => {
        // console.log(data);
        this.scrollValue = data;
        this.fixBtn(this.scrollValue);
      }
    });
  }

  ngOnInit() {
    // this.getAllProduct();
    // console.log(this.coupons);
    // this.getAllSubProduct();
    // console.log(this.firstValue);
    // console.log(this.difference);
    const vh = window.innerHeight * 0.01;
    // Then we set the value in the --vh custom property to the root of the document
    // document.documentElement.style.setProperty('--vh', `${vh}px`);
    // alert(vh);
    this.height = '30vh';
    // We listen to the resize event
    window.addEventListener('resize', () => {
      // We execute the same script as before
      const vha = window.innerHeight * 0.01;
      // alert(vh);
      // alert(vha);
      if (vha < vh) {
        const data = (vh / vha * 30);
        this.height = data + 'vh';
      } else {
        this.height = '30vh';
      }
      // document.documentElement.style.setProperty('--vh', `${vh}px`);
    });
  }

  shopNow(subcatId: string, subProd) {
    // tslint:disable: prefer-for-of
    // console.log('btn id is : ', subcatId, subProd);
    const btnVal = document.getElementById(subcatId).innerText;
    const elementShop = document.getElementById(subcatId);
    // console.log('btnVal issss...', btnVal);
    // console.log('elementShop issss...', elementShop);
    // this.buttonName = 'Shop Now';
    if (btnVal === 'Earn AED') {
      elementShop.classList.add('shopBtnShop');
      document.getElementById(subcatId).innerText = 'Shop Now';
    }
    else if (btnVal === 'Shop Now') {
      var test2 = localStorage.getItem("mobileNo");
      if (localStorage.getItem("mobileNo") === null) {

        this.router.navigate(['/login/login']);
      }
      else {
        localStorage.removeItem('subProdDetails');
        localStorage.removeItem('offer');

       // localStorage.clear();

        localStorage.setItem('subProdDetails', JSON.stringify(subProd));
        localStorage.setItem('offer', JSON.stringify(subcatId));
        this.router.navigate(['/offer']);
      }
      console.log(test2 + "     test2");
      //localStorage.clear();
      //localStorage.setItem('subProdDetails', JSON.stringify(subProd));
      // localStorage.setItem('offer', JSON.stringify(subcatId));
      //  this.router.navigate(['/offer']);
    }
  }

  fixBtn(data: number) {
    const dataEle = document.getElementsByClassName('collapse sub-product show') as HTMLCollectionOf<HTMLElement>;
    for (let i = 0; i < dataEle.length; i++) {
      const divId = +dataEle[i].id.replace('demo', '');
      // console.log((this.firstValue + ((divId - 1) * this.difference)), data);
      if ((divId === 1 && data >= 250) || (divId > 1 && data >= (this.firstValue + ((divId - 1) * this.difference)))) {
        document.getElementById('btntoggle' + divId).classList.add('fixed-btn');
      } else {
        this.removeFixBtn();
      }
      // if (dataEle[i].id !== divID) {
      //   dataEle[i].classList.remove('show');
      // }
      // console.log(divId);
    }
  }

  displayDiv(iconId: string, element: string, extendedDiv: string) {
    // this.showDiv = !this.showDiv;
    // this.hideDiv = !this.hideDiv;
    // this.plusMInus = !this.plusMInus;
    // const re = /prodicon/gi;
    // const prodId = element.replace(re, '');
    // console.log(element);
    this.hideExtendedShare(extendedDiv);
    // this.showShareBtns();
    const dataEle = document.getElementsByClassName('shareBtns') as HTMLCollectionOf<HTMLElement>;
    for (let i = 0; i < dataEle.length; i++) {
      const ele = dataEle[i];
      if (!(ele.id === element)) {
        ele.classList.remove('hide');
      }
    }
    // console.log('helloooooooooooo', prodId);
    document.getElementById(element).classList.toggle('hide');
    // document.getElementById('prod' + prodId).classList.toggle('show');
    const elements = document.querySelectorAll('.plusIcon.fa-minus');
    elements.forEach(ele => {
      if (!(ele.id === iconId)) {
        ele.classList.toggle('fa-minus');
      }
    });
    document.getElementById(iconId).classList.toggle('fa-minus');
    document.getElementById(extendedDiv).classList.toggle('show');
    // if (elements.length === 0) {
    //   document.getElementById('prodsharehide' + prodId).style.display = 'flex';
    // } else {
    //   console.log('coming ', prodId);
    //   document.getElementById('prodsharehide' + prodId).style.display = 'none';
    // }
  }

  // openShare() {
  //     this.openSharePop = !this.openSharePop;
  // }
/*   openShare(shareId: string) {
    // console.log('btn id is : ', shareId);
    this.hideAllShare();
    const popup = document.getElementById(shareId);
    popup.classList.toggle('show');
  } */

  //update 12-12-2020
  openShare(shareId: string) {
     console.log('btn id is : ', shareId);
    this.hideAllShare();
    const popup = document.getElementById(shareId);
   popup.classList.toggle('show');

   //this.router.navigate["/share"];
  }
  openShare1() {
  this.router.navigate["/share"];
 }


  toggle(element: string) {
    // console.log(element);
    this.showShareBtns();
    this.removeFixBtn();
    this.hideExtendedShare('0');
    this.hideAllShare();
    this.fixBtnTog = false;
    //  var varBtn = document.getElementsByName("element");
    const elements = document.querySelectorAll('.fa-minus');
    const cardExpElements = document.querySelectorAll('.cardExpand');
    // console.log(cardExpElements);
    // console.log(elements);

    const re = /icon/gi;
    const btnid = element.replace(re, '');
    // console.log('button id is...', btnid);

    cardExpElements.forEach(elem => {
      // console.log(elem.id);
      if (!(elem.id === ('cardexp' + btnid))) {
        elem.classList.toggle('cardExpand');
      }
    });
    const cardExpId = document.getElementById('cardexp' + btnid);
    cardExpId.classList.toggle('cardExpand');
    elements.forEach(ele => {
      // console.log(ele.id);
      if (!(ele.id === element)) {
        ele.classList.toggle('fa-minus');
        // let removeBtnId = document.getElementById(this.varBtn);
        // removeBtnId.classList.remove('addBtnStick');
        // let cardExpId = document.getElementById('cardexp' + btnid);
        // cardExpId.classList.remove('cardExpand');
      }
    });
    const data = document.getElementById(element);
    data.classList.toggle('fa-minus');
    if (elements.length === 0) {
      this.fixBtnTog = !this.fixBtnTog;
      this.varBtn = 'btntoggle' + btnid;
      // let cardExpId = document.getElementById('cardexp' + btnid);
      // cardExpId.classList.add("cardExpand");
    } else {
      this.fixBtnTog = false;
      // let removeBtnId = document.getElementById(this.varBtn);
      // removeBtnId.classList.remove("addBtnStick");
      // let cardExpId = document.getElementById('cardexp' + btnid);
      // cardExpId.classList.remove("cardExpand");
    }
  }
  showShareBtns() {
    const dataEle = document.getElementsByClassName('shareBtns') as HTMLCollectionOf<HTMLElement>;
    for (let i = 0; i < dataEle.length; i++) {
      dataEle[i].classList.remove('hide');
    }
  }

  hideExtendedShare(divID: string) {
    const dataEle = document.getElementsByClassName('expanded') as HTMLCollectionOf<HTMLElement>;
    for (let i = 0; i < dataEle.length; i++) {
      if (dataEle[i].id !== divID) {
        dataEle[i].classList.remove('show');
      }
    }
  }
  removeFixBtn() {
    const dataEle = document.getElementsByClassName('fixed-btn') as HTMLCollectionOf<HTMLElement>;
    for (let i = 0; i < dataEle.length; i++) {
      dataEle[i].classList.remove('fixed-btn');
    }
  }
  hideAllShare() {
    const dataEle = document.getElementsByClassName('popuptext') as HTMLCollectionOf<HTMLElement>;
    // dataEle.classList.add('hide');
    // for (const ele of dataEle) {

    // }
    for (let i = 0; i < dataEle.length; i++) {
      dataEle[i].classList.remove('show');
    }
  }

  getAllProduct() {
    this.couponService.getAllProduct().subscribe(data => {
      // console.log(data);
      this.coupons = data.productresponses;
      console.log('AllProduct List:', this.coupons);
    }, error => {
      console.log(error);
    });
  }

  getAllSubProduct() {
    this.couponService.getAllSubProduct().subscribe(data => {
      console.log('AllSubProduct Data are====', data);
      this.prodCard = data.responses;
    }, error => {
      console.log(error);
    });
  }

  addToWishlistBtn(var1, var2) {
    // console.log('valueeeee isss', var1, var2);
    const data = {
      'prodId': var1,
      'subproductId': var2
    };
    if (localStorage.getItem("mobileNo") === null) {

      this.router.navigate(['/login/login']);
    }
    this.toggleBtn = !this.toggleBtn;
    const cardWishListId = document.getElementById('AddWishToggle' + var1 + var2);
    // console.log("id "+'AddWishToggle' + var1 + var2);
    // console.log(cardWishListId);
    if (this.toggleBtn == true) {
      cardWishListId.classList.remove('black');
      cardWishListId.classList.toggle('red');
    } else {
      cardWishListId.classList.remove('red');
      cardWishListId.classList.toggle('black');
    }

    // this.couponService.addToWishlist(data).subscribe(data => {
    //   console.log(data);
    //   // this.couponsList = data.responseList;
    // }, error => {
    //   console.log(error);
    // });
  }

  addToWishlistBtn2(var1, var2) {
    // console.log('valueeeee isss', var1, var2);
    const data = {
      'prodId': var1,
      'subproductId': var2
    };
    this.toggleBtn = !this.toggleBtn;
    const cardWishListId = document.getElementById('AddWishToggle2' + var1 + var2);
    // console.log("id "+'AddWishToggle' + var1 + var2);
    // console.log(cardWishListId);
    if (this.toggleBtn == true) {
      cardWishListId.classList.remove('black');
      cardWishListId.classList.toggle('red');
    } else {
      cardWishListId.classList.remove('red');
      cardWishListId.classList.toggle('black');
    }

    // this.couponService.addToWishlist(data).subscribe(data => {
    //   console.log(data);
    //   // this.couponsList = data.responseList;
    // }, error => {
    //   console.log(error);
    // });
  }


  public getSubProductByProdId(data) {
    this.couponService.getSubProductByProdId(data).subscribe(result => {
      // console.log('=========== SubProductByProdId Details: ' + data + '===========');
      this.prodCard = result.responses;
      console.log('subProdListbyId issss .......', result.responses);
      // let wishStringVar = result.responses.wishStatus;
      // var boolValue = wishStringVar.toLowerCase() == "true" ? true : false;
      // console.log('Flag Is', wishStringVar );
      // console.log('boolValue of Flag Is', boolValue );
    }, error => {
      console.log(error);
    });
  }

}
