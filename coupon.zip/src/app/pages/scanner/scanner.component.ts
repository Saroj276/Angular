import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Scanner1Service } from 'src/app/services/scanner1.service';
@Component({
  selector: 'app-scanner',
  templateUrl: './scanner.component.html',
  styleUrls: ['./scanner.component.scss']
})
export class ScannerComponent implements OnInit {

  qrResultString: string = null;
  // result1: string;
  isClicked = false;
  test: string;
  result = 'https://test.wifi10x.com/Coupon';
  actv2: boolean = false;
  @Output() newItemEvent = new EventEmitter<boolean>();

  constructor(private scanRes: Scanner1Service) { }

  ngOnInit() {
  }


  clearResult(): void {
    this.qrResultString = null;
  }
  onCodeResult(resultString) {
    this.qrResultString = resultString;
    console.log(resultString);
    if (resultString === this.result) {
      this.actv2 = true;
      this.scanRes.setShowData(true);
      this.newItemEvent.emit(this.actv2);
    }
    else {
      this.actv2 = false;
    }
    // if (resultString.includes("https://")) {
    //   this.result1 = resultString;
    // }
    // else {
    //   this.test = "https://";
    //   this.result1 = this.test.concat(resultString);
    // }
    //this.router.navigate(['/scanResult/:resultString']);

  }


}
