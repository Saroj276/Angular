import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConstants } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(
    private http: HttpClient,
  ) { }
  validateCouponCode(data): Observable<any> {
    return this.http.post(AppConstants.BASE_API_URL + 'wifi-portal/getOfferDetails', data);
  }
  addToCart(data): Observable<any> {
    return this.http.post(AppConstants.BASE_API_URL + 'wifi-portal/addToCart', data);
  }
}
