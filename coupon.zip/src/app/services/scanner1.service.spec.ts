import { TestBed } from '@angular/core/testing';

import { Scanner1Service } from './scanner1.service';

describe('Scanner1Service', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Scanner1Service = TestBed.get(Scanner1Service);
    expect(service).toBeTruthy();
  });
});
