import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Scanner1Service {

  constructor() { }

 private showData:boolean;
 getShowData()
 {
   return this.showData;
 }
 setShowData(showData1:boolean)
 {
   return this.showData=showData1;
 }

 

}
