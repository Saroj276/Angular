import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppConstants } from 'src/app/app.constants';

@Injectable({
  providedIn: 'root'
})
export class SigninService {

  constructor(
    private http: HttpClient
  ) { }
  sendOTP(data): Observable<any> {
    return this.http.post(AppConstants.BASE_API_URL + 'wifi-portal/generateOtp', data);
  }
  validateOtp(data): Observable<any> {
    return this.http.post(AppConstants.BASE_API_URL + 'wifi-portal/validateRegOtp', data);
  }
  createUser(data): Observable<any> {
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json');
    return this.http.post(AppConstants.BASE_API_URL + 'wifi-portal/createuser', data, { headers });
  }
}
