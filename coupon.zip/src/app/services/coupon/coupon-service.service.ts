import { Injectable, EventEmitter } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import { AppConstants } from 'src/app/app.constants';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CouponServiceService {
  getUpdatedData = new EventEmitter();
  subsVar: Subscription;
  constructor(
    private http: HttpClient,
  ) { }

  onChangeClaimComponent() {
    console.log('Inside Event Emitter...');
    this.getUpdatedData.emit();
  }

  public getAllProduct(): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getAllProduct');
  }
  public getAllSubProduct(): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getAllSubProduct');
  }
  public getAllCategory(): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getAllCategory');
  }
  public getAllBrand(): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getAllBrand');
  }
  public getAllSubCategory(): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getAllSubCategory');
  }
  public getSubProductByProdId(id: number): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getSubProductByProdId/' + id);
  }
  public getAllSubCategoryByCatId(id: number): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getAllSubCategoryByCatId/' + id);
  }
  public getAllCart(): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getAllCart');
  }
  public getProductBySubCategoryId(id: number): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getProductBySubCategoryId/' + id);
  }
  public getProductByCategoryId(id: number): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getProductByCategoryId/' + id);
  }
  public getProductByBrandId(id: number): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getProductByBrandId/' + id);
  }
  public getBanner(): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getBanner');
  }
  public addToWallet(data) {
    return this.http.post(AppConstants.BASE_API_URL + 'wifi-portal/addToWallet', data);
     /* return this.http.post("http://192.168.0.82:8080/wifi10xapi/wifi-portal/addToWallet", data);  */
  }
  // public addToWishlist(data) {
  //   return this.http.post(AppConstants.BASE_API_URL + 'wifi-portal/addWish', data);
  // }
  public getAllWallet(): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getAllWallet');
  }
  public getWishList(): Observable<any> {
    return this.http.get(AppConstants.BASE_API_URL + 'wifi-portal/getWishList');
  }
  public getLocationWiseCoupon(data): Observable<any> {
    return this.http.post(AppConstants.BASE_API_URL + 'wifi-portal/detailsfromStore', data);
  }
}
