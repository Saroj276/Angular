import { environment } from './../environments/environment';
import { Injectable } from '@angular/core';

@Injectable()
export class AppConstants {
    // DEVELOPMENT IP
    public static get BASE_API_URL(): string {
        if (environment.production) {
            console.log(window.location.href);
            const URL = (window.location.href).split('/');
            const CUR_SERVER_LOC = URL[0] + '//' + URL[2];
            // console.log((window.location.href).split('/index.html')[0])
            console.log(CUR_SERVER_LOC);
            localStorage.setItem('serverLocation', JSON.stringify(CUR_SERVER_LOC));
            // PRODUCTION SERVER PATH
            const SERVER_LOC = JSON.parse(localStorage.getItem('serverLocation'));
            // return 'https://' + SERVER_LOC + '//'; Previously
            // return SERVER_LOC + '//';
            return 'https://test.wifi10x.com/wifi10xapi/';
        } else {
            // DEVELOPMENT SERVER PATH
            return 'https://test.wifi10x.com/wifi10xapi/';  // Production
        }
    }

    getServerLocation() {
        // const CUR_SERVER_LOC = (window.location.href).split('#')[0].split('/')[2];
        console.log(window.location.href);
        const URL = (window.location.href).split('/');
        const CUR_SERVER_LOC = URL[0] + '//' + URL[2];
        // console.log((window.location.href).split('/index.html')[0])
        console.log(CUR_SERVER_LOC);
        localStorage.setItem('serverLocation', JSON.stringify(CUR_SERVER_LOC));
    }
}
