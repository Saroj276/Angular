import { LoginHeaderComponent } from './pages/login-header/login-header.component';
import { SurveyNewComponent } from './pages/survey-new/survey-new.component';
import { ShowCouponComponent } from './pages/coupon/show-coupon/show-coupon.component';
import { FilterComponent } from './pages/coupon/filter/filter.component';
import { CouponCardComponent } from './pages/coupon/coupon-card/coupon-card.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { OfferDetailsComponent } from './pages/offer-details/offer-details.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { LoginComponent } from './pages/login/login.component';
import { OfferDetails2Component } from './pages/offer-details2/offer-details2.component';
import { RegistrationComponent } from './pages/registration/registration.component';
import { HomeComponent } from './pages/home/home.component';
import { CartComponent } from './pages/cart/cart.component';
import { SearchBarComponent } from './pages/search-bar/search-bar.component';
import { EarnHeaderComponent } from './pages/earn-header/earn-header.component';
import { DashboarddeskComponent } from './pages/dashboarddesk/dashboarddesk.component';
import { RegistrationNewComponent } from './pages/registration-new/registration-new.component';
import { LoginNewComponent } from './pages/login-new/login-new.component';
import { SearchPageComponent } from './pages/search-page/search-page.component';
import { SearchMenuComponent } from './pages/search-menu/search-menu.component';
import { CategorypageComponent } from './pages/categorypage/categorypage.component';
import { ScrollComponent } from './pages/scroll/scroll.component';
import { ProdscrollComponent } from './pages/prodscroll/prodscroll.component';
import { LocationComponent } from './pages/location/location.component';
import { WalletComponent } from './pages/wallet/wallet.component';
import { ShareComponent } from "./pages/share/share.component";

const routes: Routes = [
  {
    path: '',
    redirectTo: 'category',
    pathMatch: 'full'
  }
  , {
    //   path: 'card',
    //   component: CouponCardComponent
    // }, {
    //   path: 'filter',
    //   component: FilterComponent
    // },
    // {
    path: 'coupon',
    component: ShowCouponComponent
  }, {

    path: 'offer',
    // component: OfferDetailsComponent
    component: OfferDetails2Component
  },
  // {
  //   path: 'loginNew',
  //   component: LoginNewComponent
  // },
  // {
  //   path: 'registrationNew',
  //   component: RegistrationNewComponent
  // },
  //  {
  //   path: 'survey',
  //   component: SurveyNewComponent
  // },
  {
    path: 'search',
    component: SearchBarComponent

  },
  {
    path: 'home',
    component: DashboardComponent

  },
  {
    path: 'category',
    component: CategorypageComponent
  },
  {
    path: 'location',
    component: LocationComponent
  },
   {
    path: 'wallet',
    component: WalletComponent
  },
  // , {
  // path: 'banner',
  //   component: HomeComponent

  // },
  {
    path: 'cart',
    component: CartComponent
  },
  {
    path: 'searchPage',
    component: SearchPageComponent
  }, {
    path: 'searchMenu',
    component: SearchMenuComponent
  },
  {
    path: 'prod',
    component: ProdscrollComponent
  },
  {
    path: 'scroll',
    component: ScrollComponent
  }
  //
  // , {
  //   path: 'login',
  //   component: LoginComponent
  // }
  , {
    path: 'dashboardDesk',
    component: DashboarddeskComponent
  },
  //   , {
  //   path: 'earn',
  //     component: EarnHeaderComponent
  // }
  // , {
  //   path: 'register',
  //   component: RegistrationComponent
  // },
  {
    path: 'login', component: LoginHeaderComponent,
    children: [
      { path: '', redirectTo: 'login', pathMatch: 'full' },
      { path: 'login', component: LoginNewComponent },
      { path: 'register', component: RegistrationNewComponent }
    ]
  },{
    path: 'share',
    component: ShareComponent
    
  }

  //  ,{  path: 'cart',
  //   component: CartComponent
  // }

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true, preloadingStrategy: PreloadAllModules
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
